import joblib
import numpy as np
import os

# ✅ Load your Random Forest model (only once when FastAPI starts)
MODEL_PATH = os.path.join(os.path.dirname(__file__), "randomforest.pkl")
model = joblib.load(MODEL_PATH)

def predict_crop(data: dict):
    N = data.get("N")
    P = data.get("P")
    K = data.get("K")
    temperature = data.get("temperature")
    humidity = data.get("humidity")
    ph = data.get("ph")
    rainfall = data.get("rainfall")

    X = np.array([[N, P, K, temperature, humidity, ph, rainfall]])
    return model.predict(X)[0]

    
