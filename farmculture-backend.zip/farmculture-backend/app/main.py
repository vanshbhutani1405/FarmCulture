
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

# Import your main router
from app.routes import router as api_router

# Load environment variables from .env
load_dotenv()


# App initialization
app = FastAPI(
    title="🌾 FarmCulture API",
    description="AI-powered Smart Crop & Cultivation Recommender",
    version="1.0.0",
)


# CORS Setup — allows React frontend or any client to access API

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # later restrict to frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Register Routers

app.include_router(api_router)


# Root route (sanity check)

@app.get("/", tags=["Health"])
def read_root():
    return {
        "message": "Welcome to FarmCulture Backend 👩‍🌾",
        "docs_url": "/docs",
        "status": "running ✅",
    }

# Run the app directly (for local dev)
if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 8000)),
        reload=True,
    )
